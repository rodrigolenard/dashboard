<?php
include_once $_SERVER['DOCUMENT_ROOT'].'/config/config.php';          // MMDVMDash Config
include_once $_SERVER['DOCUMENT_ROOT'].'/dashboard/mmdvmhost/tools.php';        // MMDVMDash Tools
include_once $_SERVER['DOCUMENT_ROOT'].'/dashboard/mmdvmhost/functions.php';    // MMDVMDash Functions
include_once $_SERVER['DOCUMENT_ROOT'].'/config/language.php';	      // Translation Code

?>
        <table class="table-responsive">
		<table class="table table-hover">
		<thead class="text-warning" data-background-color="">
		<th style=text-align:center>Hora Local</th>
		<th style=text-align:center>Operação</th>
		<th width="0">ID - QRA</th>
		<th width="0">Destino</th>
		<th style=text-align:center; width="0">Origem</th>
		<th style=text-align:center; width="0">Duração</th>
		<th style=text-align:center; width="0">Perca</th>
		<th style=text-align:center; width="0">BER</th>
		<th style=text-align:center; width="0">RSSI</th>
        </thead>  

<?php
$i = 0;
for ($i = 0;  ($i <= 10); $i++) { //Last 30 calls
	if (isset($lastHeard[$i])) {
		$listElem = $lastHeard[$i];
		if ( $listElem[2] ) {
			$utc_time = $listElem[0];
                        $utc_tz =  new DateTimeZone('UTC');
                        $local_tz = new DateTimeZone(date_default_timezone_get ());
                        $dt = new DateTime($utc_time, $utc_tz);
                        $dt->setTimeZone($local_tz);
                        $local_time = $dt->format('d F - H:i:s');

		// Mostra QRA na Tabela
		$CallName = exec("grep '$listElem[2]' /usr/local/etc/DMRIds.dat");

		echo"<tr>";
		echo"<td width=\"0\" align=\"center\">$local_time</td>"; // Hora e data na tabela
		echo"<td width=\"0\" align=\"center\"> $listElem[1]</td>"; // Mostra modo de operação
		if (is_numeric($listElem[2]) || strpos($listElem[2], "openSPOT") !== FALSE) {
		echo "<td align=\"center\">$listElem[2]</td>"; // Mostra ID no Indicativo
		} elseif (!preg_match('/[A-Za-z].*[0-9]|[0-9].*[A-Za-z]/', $listElem[2])) {
        echo "<td align=\"left\">$listElem[2] - $resultado</td>";
		} 
			else {
			if (strpos($listElem[2],"-") > 0) { $listElem[2] = substr($listElem[2], 0, strpos($listElem[2],"-")); }
			if ( $listElem[3] && $listElem[3] != '    ' ) {
		echo "<td width=\"18\" align=\"left\"><a href=\"http://www.qrz.com/db/$listElem[2]\" target=\"_blank\">$listElem[2]</a> - INFO</td>"; // Mostra indicativo modo D-Star
			} 
			else {
			echo "<td width=\"0\" align=\"left\">$CallName</td>"; // Mostra opção indicativo e QRA na tabela
			}
		}

		if ( substr($listElem[4], 0, 6) === 'CQCQCQ' ) {
			echo "<td width=\"12\" align=\"left\">$listElem[4]</td>";
		} else {
			echo "<td align=\"center\">".str_replace("","&nbsp;", $listElem[4])."</td>"; // Mostra destino da chamda
		}


		if ($listElem[5] == "RF"){
			echo "<td  width=\"135\" align=\"center\" style=\"background:#972FB0;\"><font color=\"#fff\"><b>RF Hostpot</b></td>"; // Mostra origem da chamda via RF
		}else{
			echo "<td width=\"125\" width=\"2\" align=\"center\">$listElem[5]</td>"; // Mostra origem da chamda via Internet
		}
		if ($listElem[6] == null) {
				echo "<td align=\"center\" style=\"background:#f00;\"><b><font color=\"#fff\"><b>TX</b></b></td><td></td><td></td>"; // Mostra modo TX via Internet
			} else if ($listElem[6] == "SMS") {
				echo "<td align=\"center\" width=\"10\" style=\"background:#00ffbf;\"><b>SMS</b></td><td></td><td></td>"; // Mostra modo SMS
			} else {
			echo "<td width=\"90\"  align=\"center\">$listElem[6]</td>"; // Mostra duração da chamda

			// Mostra cor perca de pacote
			if (floatval($listElem[7]) == 0) { echo "<td width=\"90\"  align=\"center\">$listElem[7]</td>"; } // Porcentagem de perca de pacote
			elseif (floatval($listElem[7]) >= 0.0 && floatval($listElem[7]) <= 3.0) { echo "<td align=\"center\" style=\"background:#1d1;\">$listElem[7]</td>"; }
			elseif (floatval($listElem[7]) >= 3.1 && floatval($listElem[7]) <= 7.0) { echo "<td align=\"center\" style=\"background:#fa0;\">$listElem[7]</td>"; }
			else { echo "<td width=\"90\" align=\"center\" style=\"background:#F00;\"><font color=\"#fff\"><b>$listElem[7]</b></td>"; }

			// Mostra cor do BER
			if (floatval($listElem[8]) == 0) { echo "<td width=\"90\"  align=\"center\">$listElem[8]</td>"; } // Porcentagem de perca de BER
			elseif (floatval($listElem[8]) >= 0.0 && floatval($listElem[8]) <= 3.0) { echo "<td width=\"90\"  align=\"center\" style=\"background:#1d1;\">$listElem[8]</td>"; }
			elseif (floatval($listElem[8]) >= 3.1 && floatval($listElem[8]) <= 7.0) { echo "<td align=\"center\" style=\"background:#fa0;\">$listElem[8]</td>"; }
			else { echo "<td align=\"center\" style=\"background:#f00;\"><font color=\"#fff\"><b>$listElem[8]</b></td>"; }
			echo"<td width=\"120\" width=\"8\" align=\"center\">$listElem[9]</td>"; //rssi
		}
		
		}
	}
}
?>
