<?php
// Set the language
$pistarLanguage='portuguese_pt';
include_once $_SERVER['DOCUMENT_ROOT']."/lang/$pistarLanguage.php";
?>
