<?php
include_once $_SERVER['DOCUMENT_ROOT'].'/config/config.php';          // MMDVMDash Config
include_once $_SERVER['DOCUMENT_ROOT'].'/dashboard/mmdvmhost/tools.php';        // MMDVMDash Tools
include_once $_SERVER['DOCUMENT_ROOT'].'/dashboard/mmdvmhost/functions.php';    // MMDVMDash Functions
include_once $_SERVER['DOCUMENT_ROOT'].'/config/language.php';	      // Translation Code

?>
    <div class="container-fluid">
	  <div class="row">
            <div class="col-lg-3 col-md-6 col-sm-6">
              <div class="card card-stats">
                <div class="card-header card-header-info card-header-icon">
                  <div class="card-icon">
                    <i class="material-icons">info_outline</i>
                  </div>
                  <p class="card-category">Modo</p>
                  <h3 class="card-title"><small>D-Star</small>
                  </h3>
                </div>
                <div class="card-footer">
                  <div class="stats">
                    <i class="material-icons"></i>
                    <h4>Status:&nbsp<?php showMode("D-Star", $mmdvmconfigs);?></h>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6">
              <div class="card card-stats">
                <div class="card-header card-header-info card-header-icon">
                  <div class="card-icon">
                    <i class="material-icons">info_outline</i>
                  </div>
                  <p class="card-category">Modo</p>
                  <h3 class="card-title"><small>DMR</small></h3>
                </div>
                <div class="card-footer">
                  <div class="stats">
                    <h4>Status:&nbsp<?php showMode("DMR", $mmdvmconfigs);?></div></h3>
                </div>
              </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6">
              <div class="card card-stats">
                <div class="card-header card-header-info card-header-icon">
                  <div class="card-icon">
                    <i class="material-icons">info_outline</i>
                  </div>
                  <p class="card-category">Modo</p>
                  <h3 class="card-title"><small>APCO 25</small></h3>
                </div>
                <div class="card-footer">
                  <div class="stats">
                    <h4>Status:&nbsp<?php showMode("P25", $mmdvmconfigs);?></div></h3>
                </div>
              </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6">
              <div class="card card-stats">
                <div class="card-header card-header-info card-header-icon">
                  <div class="card-icon">
                    <i class="material-icons">info_outline</i>
                  </div>
                  <p class="card-category">Modo</p>
                  <h3 class="card-title"><small>YSF Fusion</small></h3>
                </div>
                <div class="card-footer">
                  <div class="stats">
                    <h4>Status:&nbsp<?php showMode("System Fusion", $mmdvmconfigs);?></div></h3>
                </div>
              </div>
            </div>
          </div>